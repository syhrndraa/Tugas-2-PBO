/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaswing;

/**
 *
 * @author ASUS
 */
public class Kerucut implements BangunDatar, BangunRuang {
    double jari, tinggi;

    public Kerucut (double jari, double tinggi) {
        this.jari = jari;
        this.tinggi = tinggi;
    }
    
    @Override
    public double luas() {
        return Math.PI*Math.pow(jari, 2);
    }

    @Override
    public double keliling() {
        return 2*Math.PI*jari;
    }

    @Override
    public double volume() {
        return Math.PI*Math.pow(jari, 2)*tinggi/3;
    }

    @Override
    public double luasPermukaan() {
        return (Math.PI*Math.pow(jari, 2))+(Math.PI*jari*Math.sqrt(Math.pow(jari, 2)+Math.pow(tinggi, 2)));
    }
}
