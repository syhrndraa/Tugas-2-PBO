/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaswing;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

class GUI extends JFrame implements ActionListener {
    double jari, tinggi;
    
        JLabel ljari = new JLabel("Jari - Jari");
        final JTextField fjari = new JTextField(5);
        JLabel ltinggi = new JLabel("Tinggi");
        final JTextField ftinggi = new JTextField(5);
        
        JButton benter = new JButton("Enter");
        
        JLabel lluas = new JLabel("");
        JLabel lkeliling = new JLabel("");
        JLabel lvolume = new JLabel("");
        JLabel lpermukaan = new JLabel("");
        
        JButton breset = new JButton("Reset");
        
    private Object input;
        public GUI() {
            setSize(400,500);
            
            setLayout(null);
            add(ljari);
            add(fjari);
            add(ltinggi);
            add(ftinggi);
            add(benter);
            add(breset);
            
            ljari.setBounds(10,10,120,20);
            fjari.setBounds(130,10,150,20);
            ltinggi.setBounds(10,35,120,20);
            ftinggi.setBounds(130,35,150,20);
            benter.setBounds(130,90,70,20);
            breset.setBounds(130,215,70,20);
            setVisible(true);
            
            benter.addActionListener(this);
            breset.addActionListener(this);
            
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
        } 

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        if(e.getSource() == benter)
        {
            
            
            try{
             jari = Double.valueOf(fjari.getText());
             tinggi = Double.valueOf(ftinggi.getText());
             
             Kerucut b = new Kerucut(jari, tinggi);
            
             lluas = new JLabel("Luas Lingkaran      = " + b.luas());
             lkeliling = new JLabel("Keliling Lingkaran  = " + b.keliling());
             lvolume = new JLabel("Volume Kerucut     =" + b.volume());
             lpermukaan = new JLabel("Luas Permukaan   = " + b.luasPermukaan());
            
             add(lluas);
             add(lkeliling);
             add(lvolume);
             add(lpermukaan);
            
             lluas.setBounds(80,120,160,20);
             lkeliling.setBounds(80,140,160,20);
             lvolume.setBounds(80,165,160,20);
             lpermukaan.setBounds(80,185,160,20);
             setVisible(true);
             
            }catch(Exception error){
                 String message = "Error, belum mengisi seluruh input";
                JOptionPane.showMessageDialog(new JFrame(), message, "Dialog",
        JOptionPane.ERROR_MESSAGE);
            }
            
        }
        
        if(e.getSource() == breset)
        {
        fjari.setText(""); 
        ftinggi.setText("");
        lluas.setText("");
        lkeliling.setText("");
        lvolume.setText("");
        lpermukaan.setText("");
        fjari.requestFocus();
        }
        
    }
    }
/**
 *
 * @author ASUS
 */
public class JavaSwing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI g = new GUI();
    }
    
}
